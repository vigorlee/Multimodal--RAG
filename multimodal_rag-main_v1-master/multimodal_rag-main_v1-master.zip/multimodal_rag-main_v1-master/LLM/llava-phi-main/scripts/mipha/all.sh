#!/bin/bash

./scripts/mipha/pretrain.sh && ./scripts/mipha/finetune.sh